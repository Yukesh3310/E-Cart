import { Component } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {
  status = false;
  productList: any;
  public categorySelected = 'All';
  public category = [
    {
      name: 'All',
      value: 'All'
    },
    {
      name: 'Headphones',
      value: 'Headphones'
    },
    {
      name: 'Shoes',
      value: 'Shoes'
    },
    {
      name: 'Smart Watches',
      value: 'Smart Watches'
    },
    {
      name: 'Shirts/T-Shirts',
      value: 'Shirts/T-Shirts'
    }
  ]
  constructor( private cartService: CartService) {
  //  this.productList = cartService.product().subscribe(res => {console.log(res)})
  this.getCategory('All');
  }
  addToggle()
  {
    this.status = !this.status;
  }

  getCategory(value: any) {
    console.log(value);
    this.categorySelected = value;
    if (value == 'All') {
      this.productList = this.cartService.product('');
    } else {
      this.productList = this.cartService.product('').filter(res => res.category == value);
    }
    console.log(this.productList);
  }

  addToCart(product: any) {
    console.log(product);
    this.cartService.addToCart(product);
    window.alert('Your product has been added to the cart!');
  }

}
// console.log(this.signup.value);
//     this.cartService.signup(this.obj).subscribe(res => {console.log(res)})
//     this.signup.reset();
