import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private url = "http://localhost:8083/";

  constructor(private http: HttpClient) { }

  public items: Product[] = [];

  login(loginData: any){
    console.log(loginData);
    return {'acc': 'abc'};
    // return this.http.post(this.url + 'user/login', loginData);
  }
  signup(signupData: any){
    console.log(signupData);
    return this.http.post(this.url + 'user/register', signupData);
  }
  product(productData: any){
    console.log(productData);
    return productData = [
      {
        'name': 'Leaf Bass 2 HeadPhones',
        'price': '$ 250',
        'imgUrl': '../assets/images/leaf-headphones.jpg',
        'arrival': 'New',
        'category': 'Headphones'
      },
      {
        'name': 'Skull Candy Riff On ear headphones',
        'price': '$ 450',
        'imgUrl': '../assets/images/Skull-headphones.jpg',
        'arrival': '',
        'category': 'Headphones'
      },
      {
        'name': 'Sony WH-XB910N Wireless Headphones',
        'price': '$ 300',
        'imgUrl': '../assets/images/sony-headphones.jpg',
        'arrival': '',
        'category': 'Headphones'
      },
      {
        'name': 'Air Jordan retro',
        'price': '$ 250',
        'imgUrl': '../assets/images/product-1.jpg',
        'arrival': '',
        'category': 'Shoes'
      },
      {
        'name': 'Pegasus Turbo',
        'price': '$ 500',
        'imgUrl': '../assets/images/product-2.jpg',
        'arrival': '',
        'category': 'Shoes'
      },
      {
        'name': 'Nike Free Run',
        'price': '$ 500',
        'imgUrl': '../assets/images/product-3.jpg',
        'arrival': '',
        'category': 'Shoes'
      },
      {
        'name': 'Apple iwatch Nike Sports Edition',
        'price': '$ 500',
        'imgUrl': '../assets/images/apple-nike.jpg',
        'arrival': '',
        'category': 'Smart Watches'
      },
      {
        'name': 'Boult Cosmic V2 Smart Watch',
        'price': '$ 500',
        'imgUrl': '../assets/images/boult.jpg',
        'arrival': '',
        'category': 'Smart Watches'
      },
      {
        'name': 'Boat Smart Watch',
        'price': '$ 500',
        'imgUrl': '../assets/images/smartwatch.jpg',
        'arrival': '',
        'category': 'Smart Watches'
      },
      {
        'name': 'All Size Red',
        'price': '$ 500',
        'imgUrl': '../assets/images/plus size t-shirt.jpg',
        'arrival': '',
        'category': 'Shirts/T-Shirts'
      },
      {
        'name': 'Allen-solly Multi Colored Shirt',
        'price': '$ 500',
        'imgUrl': '../assets/images/multi-colored shirt.jpg',
        'arrival': '',
        'category': 'Shirts/T-Shirts'
      },
      {
        'name': 'Tommy Hilfiger White Shirt',
        'price': '$ 500',
        'imgUrl': '../assets/images/white-shirt.jpg',
        'arrival': '',
        'category': 'Shirts/T-Shirts'
      }
    ]
    // return this.http.get(this.url + '/product', productData);
  }
  cart(cartData: any){
    console.log(cartData);
    return this.http.post(this.url + '/cart', cartData);
  }
  
  addToCart(product: Product) {
    console.log(product);
    this.items.push(product);
    console.log(this.items);
  }

  getItems() {
    return this.items;
  }

  clearCart() {
    this.items = [];
    return this.items;
  }
}

export interface Product {
  name: string;
  price: number;
  imgUrl: string;
  arrival: string,
  category: string
}