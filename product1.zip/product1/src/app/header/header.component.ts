import { Component } from '@angular/core';
import { CartService } from '../cart.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  title = 'e-commerce';
  // public items: [] = [];
  //Sidebar toggle show hide function
  constructor(private cartService: CartService) { }
  items = this.cartService.getItems();
  status = false;
  addToggle()
  {
    this.status = !this.status;
  }
  scroll(el: HTMLElement) {
    el.scrollIntoView();
  }

}
